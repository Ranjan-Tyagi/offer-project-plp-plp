package com.capgemini.service;

import com.capgemini.model.Offer;

public interface OfferService {
	public void addOffer(Offer offer);
}
