package com.capgemini.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.capgemini.dao.OfferDAO;
import com.capgemini.model.Offer;

public class OfferServiceImpl implements OfferService {

	@Autowired OfferDAO dao;
	
	@Override
	public void addOffer(Offer Offer) {
		
		dao.save(Offer);
	}

}
