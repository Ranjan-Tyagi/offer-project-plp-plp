package com.capgemini.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.model.Offer;
import com.capgemini.service.OfferService;


@RestController
public class JspController1 {

	@Autowired OfferService service;

	@RequestMapping(value = "/addOffer", method = RequestMethod.POST)
	public void finalRegistrationForCustomer(@RequestBody Offer offer) {
		System.out.println(offer);
		service.addOffer(offer);
	}
	
	/*
	@RequestMapping(value="single", method=RequestMethod.GET)
	String loadSinglePage(@RequestParam("prod-id") int prodId, ModelMap model) {
		
		prodId = 23;
		RestTemplate restTemplate = new RestTemplate();
		Product product =restTemplate.getForObject("http://10.220.57.50:9096/getProductDetails?id="+prodId, Product.class);
		System.out.println(product.toString());
		model.put("prod-name", product.getName());
		model.put("price", product.getCost());
		model.put("rating", product.getAverageRating());
		model.put("image-url", product.getImageUrl());
		model.put("description", product.getDescription());
		model.put("discount", product.getDiscount().getDiscountPercentage());
		
		RestTemplate restTemplate = new RestTemplate();
		Customer customer = restTemplate.getForObject("http://localhost:9899/getCustomerDetails?id="+id, Customer.class);
		return "single";
	}*/
//	@RequestMapping("/single")
//	ModelAndView loadProductSingle() {
//		ModelAndView modelAndView = new ModelAndView("single");
//		return modelAndView;
//	}
//	
//	@RequestMapping("/men")
//	ModelAndView loadMens() {
//		ModelAndView modelAndView = new ModelAndView("mens");
//		return modelAndView;
//	}
//
//	@RequestMapping("/women")
//	ModelAndView loadWomens() {
//		ModelAndView modelAndView = new ModelAndView("womens");
//		return modelAndView;
//	}
//
//	@RequestMapping("/kids")
//	ModelAndView loadKids() {
//		ModelAndView modelAndView = new ModelAndView("kids");
//		return modelAndView;
//	}
//
//	@RequestMapping("/electronics")
//	ModelAndView loadElectronics() {
//		ModelAndView modelAndView = new ModelAndView("electronics");
//		return modelAndView;
//	}
//
//	
//
//	@RequestMapping("/cart")
//	ModelAndView loadCart() {
//		ModelAndView modelAndView = new ModelAndView("cart");
//		return modelAndView;
//	}
//
//	@RequestMapping("/my-orders")
//	ModelAndView loadMyOrders() {
//		ModelAndView modelAndView = new ModelAndView("my-orders");
//		return modelAndView;
//	}

}
